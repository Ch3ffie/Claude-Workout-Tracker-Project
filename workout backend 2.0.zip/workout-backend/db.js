const Database = require("better-sqlite3");
const path = require("path");
const fs = require("fs");

// Azure App Service mounts the app folder read-only when deployed via
// zip/GitHub Actions ("Run From Package"). WEBSITE_INSTANCE_ID is set by
// Azure App Service, so we use it to detect that environment and write
// the DB to /home/data instead — that path is persistent Azure Files
// storage and always writable, unlike the app folder itself.
const isAzure = !!process.env.WEBSITE_INSTANCE_ID;
const dbDir = process.env.DB_DIR || (isAzure ? "/home/data" : __dirname);
const dbPath = path.join(dbDir, "workout.db");

if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

const db = new Database(dbPath);
console.log(`SQLite DB path: ${dbPath}`);

db.pragma("journal_mode = WAL");

// One row per exercise, per session. Simpler to query/aggregate than
// nesting JSON blobs, and makes future features (charts, PRs) easy.
db.exec(`
  CREATE TABLE IF NOT EXISTS sessions (
    id TEXT PRIMARY KEY,          -- e.g. "2026-07-02_U1"
    day TEXT NOT NULL,            -- U1 | U2 | L1 | L2
    date TEXT NOT NULL,           -- YYYY-MM-DD
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS exercise_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    exercise TEXT NOT NULL,
    is_bodyweight INTEGER NOT NULL DEFAULT 0,
    set_index INTEGER NOT NULL,
    weight REAL,
    reps INTEGER
  );

  CREATE INDEX IF NOT EXISTS idx_logs_session ON exercise_logs(session_id);
  CREATE INDEX IF NOT EXISTS idx_sessions_day ON sessions(day);
`);

module.exports = db;
