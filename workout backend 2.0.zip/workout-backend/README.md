# Workout Tracker — Backend

A real backend for your progressive overload tracker: Node.js + Express API,
SQLite database, and the same frontend you've been using, now served by
the backend instead of relying on browser storage.

## What's in here

```
workout-backend/
├── server.js           # Express app entry point
├── db.js                # SQLite connection + schema
├── routes/
│   └── history.js       # GET/POST/DELETE /api/history
├── public/
│   └── index.html        # Your frontend (fetches from the API now)
├── package.json
└── workout.db            # Created automatically on first run
```

## Run it locally

1. Install Node.js if you don't have it: https://nodejs.org (LTS version)
2. Open a terminal in this folder and run:
   ```
   npm install
   npm start
   ```
3. Open **http://localhost:3001** in your browser — that's your tracker,
   now backed by a real database file (`workout.db`) instead of localStorage.

Your data now lives in `workout.db`. As long as that file exists, your
history persists — restarting the server, closing your laptop, none of
that touches it.

## Using it from your phone

Your phone can't reach `localhost` on your computer. Two options:

**Option A — same WiFi network (quick, free, good for home gym use):**
1. Find your computer's local IP (e.g. `192.168.1.50`) — on Mac:
   System Settings → Wi-Fi → Details. On Windows: `ipconfig` in Command Prompt.
2. On your phone's browser, go to `http://192.168.1.50:3001`
3. Add to Home Screen. Both devices now read the same database as long
   as your computer is on and running `npm start`.

**Option B — deploy it for real (works anywhere, no computer needed):**
1. Push this folder to a free host like **Render.com** or **Railway.app**
   (both have generous free tiers for small Node apps)
2. Add a **persistent disk** in the host's settings so `workout.db` survives
   restarts (both Render and Railway support this — look for "Disks" or
   "Volumes" in their dashboard)
3. Once deployed you'll get a permanent URL like `your-app.onrender.com`
   — open that on your phone, Add to Home Screen, done. Works from
   anywhere, gym or not.

If you want, I can walk you through either deployment step by step when
you're ready.

## Deploying to Azure App Service

Two things make Azure different from a normal Node host, and the code
here already accounts for both:

1. **Read-only app folder** — when you deploy via zip or GitHub Actions,
   Azure runs your app from a mounted read-only package. `db.js` detects
   Azure automatically (via the `WEBSITE_INSTANCE_ID` env variable Azure
   sets) and writes `workout.db` to `/home/data` instead, which is
   persistent, writable Azure Files storage. You don't need to configure
   anything for this — it just works.
2. **Native module build** — `better-sqlite3` compiles C++ during
   `npm install`. Azure's build system (Oryx) needs to actually run that
   install step rather than just unzip your `node_modules`.

### Steps (Azure Portal + zip deploy — simplest path)

1. In the Azure Portal, create a new **App Service**:
   - Publish: **Code**
   - Runtime stack: **Node 20 LTS** (or any 18+)
   - Operating System: **Linux**
   - Pick the free (F1) or basic (B1) tier — this app is light

2. In your new App Service → **Configuration → General settings**, set:
   - **Startup Command**: `npm start`

3. In **Configuration → Application settings**, add:
   - `SCM_DO_BUILD_DURING_DEPLOYMENT` = `true`
     (this tells Azure to run `npm install` on deploy instead of expecting
     prebuilt `node_modules`, which is required for `better-sqlite3` to
     compile correctly)

4. Deploy the code. Easiest from your terminal with the Azure CLI:
   ```
   az login
   cd workout-backend
   zip -r ../deploy.zip . -x "workout.db*"
   az webapp deploy --resource-group <your-resource-group> \
                     --name <your-app-name> \
                     --src-path ../deploy.zip \
                     --type zip
   ```
   (Or connect a GitHub repo under **Deployment Center** for automatic
   deploys on push — probably worth setting up once you're past the
   first manual deploy.)

5. Once it's live, your app is at `https://<your-app-name>.azurewebsites.net`
   — open that on your phone, Add to Home Screen, done.

### One important limitation

SQLite + `/home/data` works great for a **single instance** (which is
all you need for a personal tracker). If you ever scale the App Service
out to multiple instances, each instance won't reliably share the same
SQLite file. If that ever becomes relevant, the move at that point would
be **Azure Database for PostgreSQL** instead — but for now, single
instance + SQLite is simpler and completely sufficient.

### Checking it worked

Hit `https://<your-app-name>.azurewebsites.net/api/health` — you should
get back `{"status":"ok"}`. If you get an error instead, check
**Log stream** in the Azure Portal (under Monitoring) — it'll show
whether `better-sqlite3` failed to build or the DB path failed to write.



| Method | Endpoint              | Description                          |
|--------|------------------------|---------------------------------------|
| GET    | `/api/history`          | All sessions with nested exercise logs |
| POST   | `/api/history`          | Create or overwrite a session         |
| DELETE | `/api/history/:id`      | Delete a session by id                |
| GET    | `/api/health`           | Health check                          |

## Notes

- The database schema stores one row per set, per exercise, per session —
  this makes it easy to later add things like progress charts or PR
  tracking without restructuring anything.
- `better-sqlite3` is a native module — if `npm install` fails on your
  machine, you likely need Xcode Command Line Tools (Mac) or the
  "Desktop development with C++" workload (Windows). Let me know if you
  hit that and I'll help troubleshoot.
